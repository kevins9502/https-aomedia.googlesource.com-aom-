SSL_CERT_FILE
-------------

.. versionadded:: 3.25

.. include:: ENV_VAR.txt

Specify the file name containing CA certificates.  It overrides the
default, os-specific CA file used.
